import { Component, OnInit } from '@angular/core';
import { AttendanceService } from '../../services/attendance.service';

@Component({
  selector: 'app-attendance',
  templateUrl: './attendance.component.html',
  styleUrls: ['./attendance.component.css']
})
export class AttendanceComponent implements OnInit {

  schoolClassId: number = 1; // Example class ID
  subjectId: number = 5; // Example subject ID
  students: any[] = [];
  attendanceList: any[] = [];
  responseMessage: string = '';

  constructor(private attendanceService: AttendanceService) { }

  ngOnInit(): void {
    this.loadAttendance();
  }

  loadAttendance(): void {
    // Call the getAttendanceForClassAndSubject method
    this.attendanceService.getAttendanceForClassAndSubject(this.schoolClassId, this.subjectId)
      .subscribe(data => {
        this.students = data.map(attendance => ({
          ...attendance.student,
          isPresent: attendance.isPresent // Default isPresent from response
        }));
      });
  }

  onCheckboxChange(studentId: number, event: any): void {
    const isPresent = event.target.checked;
    const student = this.students.find(s => s.id === studentId);
    if (student) {
      student.isPresent = isPresent;
    }
  }

  markAttendance(): void {
    this.attendanceList = this.students.map(student => ({
      student: { id: student.id },
      schoolClass: { id: this.schoolClassId },
      subject: { id: this.subjectId },
      isPresent: student.isPresent,
      date: new Date().toISOString().split('T')[0] // Use current date (YYYY-MM-DD)
    }));

    this.attendanceService.markAttendance(this.attendanceList)
      .subscribe(response => {
        this.responseMessage = 'Attendance marked successfully!';
      }, error => {
        this.responseMessage = 'Failed to mark attendance!';
      });
  }
}
